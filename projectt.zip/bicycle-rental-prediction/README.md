# Bicycle Rental Prediction Using Machine Learning

A machine learning project for predicting bicycle rental demand using the UCI Bike Sharing Dataset.

## Project Overview

The project analyzes historical bicycle rental data and uses environmental and time-related factors such as temperature, humidity, season, working days, holidays, and hourly trends to predict rental demand.

The implementation follows the project report's methodology:
1. Data collection
2. Data preprocessing
3. Feature engineering
4. Train/test split
5. Machine learning model training
6. Model evaluation

## Technologies

- Python
- Pandas
- Scikit-learn
- Matplotlib
- UCI Bike Sharing Dataset

## Machine Learning Models

- Linear Regression
- Decision Tree Regressor
- Random Forest Regressor

## Evaluation

The models are evaluated using:
- Mean Absolute Error (MAE)
- Mean Squared Error (MSE)
- Root Mean Squared Error (RMSE)

## How to Run

Install the dependencies:

```bash
pip install -r requirements.txt
```

Run:

```bash
python bicycle_rental_prediction.py
```

The script downloads the UCI Bike Sharing Dataset automatically, preprocesses the data, trains the models, compares their performance, and saves results under the `results/` folder.

## Results

The generated files include:

- `results/model_comparison.csv`
- `results/actual_vs_predicted.png`

## Dataset

UCI Bike Sharing Dataset:
https://archive.ics.uci.edu/dataset/275/bike+sharing+dataset

## Note

This repository contains a reconstructed implementation based on the submitted academic project report because the original project source code was no longer available.
